﻿namespace Biljettshopen
{
    public enum SeatType { Fällstol, Bänk }
    public enum SeatStatus { Ledig, Reserverad, Upptagen }
}