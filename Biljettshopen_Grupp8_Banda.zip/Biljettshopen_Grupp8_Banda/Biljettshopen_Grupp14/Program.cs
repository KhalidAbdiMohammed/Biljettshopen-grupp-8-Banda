﻿namespace Biljettshopen
{
    class Program
    {
        static void Main(string[] args)
        {
            TicketBookingSystem bookingSystem = new TicketBookingSystem();
            bookingSystem.Run();
        }
    }
}

