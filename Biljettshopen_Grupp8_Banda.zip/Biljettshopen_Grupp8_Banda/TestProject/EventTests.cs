﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using Biljettshopen;

namespace Biljettshopen.Tests
{
    [TestClass]
    public class EventTests
    {
        [TestMethod]
        public void BookTicket_Should_ReserveSeat()
        {
            var evt = new Event("TestEvent", DateTime.Now.AddDays(1), DateTime.Now, 100, "Arena");
            var seatNumbers = new List<int> { 1, 2 };

            var reserved = evt.ReserveSelectedSeats(seatNumbers, _ => { });
            Assert.IsTrue(reserved);
            Assert.AreEqual(SeatStatus.Reserverad, evt.Seats[0].Status);
        }

        [TestMethod]
        public void ReserveSelectedSeats_ShouldFail_WhenSeatsAreAlreadyReserved()
        {
            var evt = new Event("TestEvent", DateTime.Now.AddDays(1), DateTime.Now, 100, "Arena");
            var seatNumbers = new List<int> { 1, 2 };

            var first = evt.ReserveSelectedSeats(seatNumbers, _ => { });
            var second = evt.ReserveSelectedSeats(seatNumbers, _ => { });

            Assert.IsTrue(first);
            Assert.IsFalse(second);
        }

        [TestMethod]
        public void CancelSeat_Should_FreeSeat()
        {
            var evt = new Event("TestEvent", DateTime.Now.AddDays(1), DateTime.Now, 100, "Arena");
            evt.Seats[0].Status = SeatStatus.Upptagen;

            evt.CancelSeat(evt.Seats[0].Number);
            Assert.AreEqual(SeatStatus.Ledig, evt.Seats[0].Status);
        }

        [TestMethod]
        public void CancelSeat_Should_DoNothing_IfSeatNotBooked()
        {
            var evt = new Event("TestEvent", DateTime.Now.AddDays(1), DateTime.Now, 100, "Arena");
            int seatNum = 7;

            var before = evt.Seats.First(s => s.Number == seatNum).Status;
            evt.CancelSeat(seatNum);
            var after = evt.Seats.First(s => s.Number == seatNum).Status;

            Assert.AreEqual(before, after);
        }
    }
}
