﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Biljettshopen;

namespace Biljettshopen.Tests
{
    [TestClass]
    public class PaymentProcessorMockTests
    {
        [TestMethod]
        public void ProcessPayment_ShouldBeCalled_WithCorrectAmount()
        {
            
            var mockProcessor = new Mock<IPaymentProcessor>();
            int amount = 150;

           
            mockProcessor.Object.ProcessPayment(amount);

            
            mockProcessor.Verify(p => p.ProcessPayment(amount), Times.Once);
        }
    }
}
