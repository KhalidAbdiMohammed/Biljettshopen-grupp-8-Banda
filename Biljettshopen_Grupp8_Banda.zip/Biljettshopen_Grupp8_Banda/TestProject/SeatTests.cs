﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Biljettshopen;

namespace Biljettshopen.Tests
{
    [TestClass]
    public class SeatTests
    {
        [TestMethod]
        public void Constructor_Should_SetPropertiesCorrectly()
        {
            int seatNumber = 10;
            SeatType seatType = SeatType.Fällstol;

            var seat = new Seat(seatNumber, seatType);

            Assert.AreEqual(seatNumber, seat.Number, "Platsnummer borde sättas korrekt");
            Assert.AreEqual(seatType, seat.Type, "Platsens typ borde sättas korrekt");
            Assert.AreEqual(SeatStatus.Ledig, seat.Status, "Standardstatus ska vara 'Ledig'");
        }

        [TestMethod]
        public void Status_CanBeChanged()
        {
            var seat = new Seat(1, SeatType.Bänk);

            seat.Status = SeatStatus.Reserverad;
            Assert.AreEqual(SeatStatus.Reserverad, seat.Status);

            seat.Status = SeatStatus.Upptagen;
            Assert.AreEqual(SeatStatus.Upptagen, seat.Status);
        }
    }
}

