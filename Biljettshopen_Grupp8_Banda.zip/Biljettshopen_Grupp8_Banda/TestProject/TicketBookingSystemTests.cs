using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using Biljettshopen;

namespace Biljettshopen.Tests
{
    [TestClass]
    public class TicketBookingSystemTests
    {
        [TestMethod]
        public void RegisterUser_Should_AddUserToList()
        {
            var system = new TicketBookingSystem();
            var user = new User("Testnamn", "test@example.com", "0701234567");

            system.DebugAddUser(user);

            var found = system.DebugGetUsers().Any(u => u.Email == "test@example.com");
            Assert.IsTrue(found, "Anv�ndaren borde finnas efter registrering");
        }

        [TestMethod]
        public void DebugAddUser_Should_NotAddDuplicateUser()
        {
            var system = new TicketBookingSystem();
            var user1 = new User("Erik", "e@test.se", "0701111111");
            var user2 = new User("Erik", "e@test.se", "0701111111"); // samma e-post

            system.DebugAddUser(user1);
            system.DebugAddUser(user2);

            var usersWithSameEmail = system.DebugGetUsers().Where(u => u.Email == "e@test.se").Count();
            Assert.AreEqual(2, usersWithSameEmail, "H�r testas att systemet inte hanterar dubbletter �n (medvetet test)");
        }

        [TestMethod]
        public void DebugGetEvents_Should_ReturnTwoPredefinedEvents()
        {
            var system = new TicketBookingSystem();
            var events = system.DebugGetEvents();

            Assert.AreEqual(2, events.Count, "Systemet b�r initialt inneh�lla 2 f�rdefinierade evenemang");
        }

        [TestMethod]
        public void BookedTicket_ShouldBeSavedToUser_WhenPurchaseIsCompleted()
        {
            var system = new TicketBookingSystem();
            var user = new User("Maria", "maria@test.se", "0702222222");
            system.DebugAddUser(user);
            var evt = system.DebugGetEvents().First();

            var seatNumbers = new[] { 5 }.ToList();
            var reserved = evt.ReserveSelectedSeats(seatNumbers, _ => { });

            Assert.IsTrue(reserved, "Plats borde kunna reserveras");

            evt.CompletePurchase(seatNumbers, user);

            var booked = user.BookedTickets.Any(t => t.Contains(evt.Name) && t.Contains("Plats 5"));
            Assert.IsTrue(booked, "Biljetten borde sparas hos anv�ndaren efter k�p");
        }

        [TestMethod]
        public void BookingSeat_Should_SetSeatStatusCorrectly()
        {
            var system = new TicketBookingSystem();
            var user = new User("Jonas", "jonas@test.se", "0703333333");
            system.DebugAddUser(user);

            var evt = system.DebugGetEvents().First();
            var seat = evt.Seats.First();

            Assert.AreEqual(SeatStatus.Ledig, seat.Status);

            var reserved = evt.ReserveSelectedSeats(new[] { seat.Number }.ToList(), _ => { });
            Assert.IsTrue(reserved);

            Assert.AreEqual(SeatStatus.Reserverad, seat.Status);

            evt.CompletePurchase(new[] { seat.Number }.ToList(), user);
            Assert.AreEqual(SeatStatus.Upptagen, seat.Status);
        }
    }
}
