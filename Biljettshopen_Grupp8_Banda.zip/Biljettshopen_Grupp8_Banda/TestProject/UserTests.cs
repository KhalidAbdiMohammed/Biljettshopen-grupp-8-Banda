﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Biljettshopen;
using System.Linq;

namespace Biljettshopen.Tests
{
    [TestClass]
    public class UserTests
    {
        [TestMethod]
        public void AddBookedTicket_Should_AddTicketToList()
        {
            var user = new User("Sara", "sara@example.com", "0701234567");
            user.AddBookedTicket("Halloweenfest - Plats 10 (Fällstol)");

            Assert.AreEqual(1, user.BookedTickets.Count, "Biljett ska läggas till i listan");
            Assert.AreEqual("Halloweenfest - Plats 10 (Fällstol)", user.BookedTickets[0]);
        }

        [TestMethod]
        public void ToString_And_FromString_Should_PreserveUserData()
        {
            var originalUser = new User("Ali", "ali@example.com", "0707654321");
            originalUser.AddBookedTicket("Studentfest - Plats 3 (Bänk)");
            originalUser.AddBookedTicket("Halloweenfest - Plats 1 (Fällstol)");

            var serialized = originalUser.ToString();
            var deserialized = User.FromString(serialized);

            Assert.IsNotNull(deserialized);
            Assert.AreEqual(originalUser.Name, deserialized.Name);
            Assert.AreEqual(originalUser.Email, deserialized.Email);
            Assert.AreEqual(originalUser.PhoneNumber, deserialized.PhoneNumber);
            CollectionAssert.AreEqual(originalUser.BookedTickets, deserialized.BookedTickets);
        }
    }
}
